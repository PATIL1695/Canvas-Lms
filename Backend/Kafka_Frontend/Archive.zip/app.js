//import the require dependencies
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var cors = require('cors');
var kafka = require('./kafka/client');
var passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const passportJWT = require('passport-jwt');
const JWTStrategy = passportJWT.Strategy;
var cookieParser = require('cookie-parser');
var UserModule = require('./models/user');
var PropertyModule = require('./models/property');
var BookingModule = require('./models/booking');
var mongoose = require('mongoose');
var config = require('./main');
var jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const multer=require('multer')
const path=require('path');

//var mongo=require('mongodb');
var assert=require('assert');
//var url='mongodb://localhost:27017'

//with /images url i should be directed to the images folder
app.use('/images', express.static(__dirname+'/uploads'));

//use cors to allow cross origin resource sharing
app.use(cors({ origin: 'http://localhost:8081', credentials: true }));
app.use(bodyParser.json());

app.use(bodyParser.urlencoded({
    extended: true
  }));

//Bringing in passport strategy that we just defined
require('./passport')(passport);

// need cookieParser middleware before we can do anything with cookies
app.use(cookieParser(config.secret))

// mongoose.connect(config.database,()=>{
//     console.log("Connected to mongoose")
// });

//Allow Access Control
app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8081');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS,POST,PUT,DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers');
    res.setHeader('Cache-Control', 'no-cache');
    next();
  });


// //Route to handle owner login request
// app.post('/ownlogin',(req,res,next)=>{
//     console.log("Inside owner Login Post Request mongo");
//     console.log("Req Body : ",req.body);
//     if(!req.body.email || !req.body.password) {
//         res.json({ success: false, message: 'Please enter email and password.' });
//     }else {
//             console.log("inside else owner login", req.body.email)
//             UserModule.findOne({email : req.body.email, typeOfPerson : "owner" }, async(err, user)=>{
//                 console.log("inisde find....",user)
//                 console.log("Not of null",!user)
//                 if (err) {
//                     console.log("Error",err);
//                     throw err;
//                 }
//                 if (!user) {
//                     console.log("user not found, let's create an account for him")
                    
//                     const { email, password } = req.body;
//                     const hashCost = 10;

//                     try {
//                         const userDocument = new UserModule({
//                             _id         : new mongoose.Types.ObjectId(), 
//                             email       : email, 
//                             password    : password,
//                             typeOfPerson: "owner" 
//                         });
//                         userDocument.save().then(function(){
//                             console.log(arguments);
//                         }).catch(function(){
//                             console.log("sder ", arguments)
//                         });
                        
//                         res.send({ 
//                             status  : 201,
//                             message2 : "Sir/Mam new account has been created for you, kindly login :-)" 
//                         });
                        
//                     } catch (error) {
//                         res.status(400).send({
//                         error: 'req body should take the form { email, password }',
//                         });
//                     }
//                 } else {
//                     console.log("Ellige..........")
//                     passport.authenticate(
//                         'local',
//                         { session: false },
//                         (error, user) => {
//                           console.log("Inside passport authenticate",user,error);
//                           if (error || !user) {
//                             return res.status(400).json({ error });
//                           }
                    
//                           /** This is what ends up in our JWT */
//                           const payload = {
//                             email   : user.email,
//                             userid  : user._id,
//                             expires : Date.now() + parseInt(process.env.JWT_EXPIRATION_MS),
//                           };
                    
//                           /** assigns payload to req.user */
//                           req.login(payload, {session: false}, (error,success) => {
//                             console.log("Back from login......",error,success)
//                             if (error) {
//                               res.status(400).send({ error });
//                             }
                    
//                             /** generate a signed json web token and return it in the response */
//                             const token = jwt.sign(JSON.stringify(payload), config.secret);
                            
//                             /** assign our jwt to the cookie */
//                             res.cookie('jwt', token, { httpOnly: true});
//                             console.log("Displaying jwt token",token);
//                             res.send({ 
//                                 status    : 200,
//                                 message2  : "Welcome back!!!", 
//                                 token     : token  
//                             });
//                           });
//                         },
//                     )(req, res,next);
//                 }
//             })
//     }
// })



// //the route will fetch owner dashboard details
// app.get('/getDetailsForDashboard', passport.authenticate('jwt', {session: false}), function(req, res){
//     const dataForBackend={
//         userid : req.user.userid
//     }
//     console.log("Kafka frontend, inside /getDetailsForDashboard",dataForBackend)
//     kafka.make_request('own_dashboard',dataForBackend, function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.send({
//                 status  : results.status,
//                 message : results.message
//             })
//         }else{
//             console.log("Inside else");
//                 res.send({
//                     status   : results.status,
//                     property : results.property,
//                     message  : "Successfully fetched the details for owner dashboard"
//                 })
//                 res.end();
//             }
        
//     });
// });

// //this route will fetch booking information for owner dashboard
// app.get('/getBookingDetailsForThisProperty', passport.authenticate('jwt', {session: false}), function(req, res){
//     console.log("Data received as request query parameter", req.query.id)
//     const dataForBackend={
//         propertid : req.query.id
//     } 
//     console.log("Data for backend....",dataForBackend);
//     kafka.make_request('book_details_own_dash',dataForBackend, function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.send({
//                 status  : results.status,
//                 message : results.message
//             })
//         }else{
//             console.log("Inside else");
//                 res.send({
//                     status     : results.status,
//                     whoBooked  : results.whoBooked,
//                     message    : "Successfully fetched who has booked this property."
//                 })
//                 res.end();
//             }
        
//     });
// });


// //this route will fetch details for details page - pre-populate 
// app.post('/kjjhbhvgh', passport.authenticate('jwt', {session: false}), function(req, res){
//     console.log("Data received in request body", req.body)
//     kafka.make_request('get_bkg_details_for_prop',req.body, function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.json({
//                 status:"error",
//                 msg:"System Error, Try Again."
//             })
//         }else{
//             console.log("Inside else");
//                 res.json({
//                     updatedList:results
//                 });

//                 res.end();
//             }
        
//     });
// });

// //this route is used to save the property details entered by the owner
// app.post('/savedetails', passport.authenticate('jwt', {session: false}), function(req, res){
//     console.log("Data received in request body, /saveDetails, kafka frontend", req.body)
//     kafka.make_request('save_details',req.body, function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.send({
//                 status  :   results.status,
//                 msg     :   results.message
//             })
//         }else{
//             console.log("Inside else");
//             res.send({
//                 status  :   results.status,
//                 msg     :   results.message
//             })
//             res.end();
//             }
        
//     });
// });


// //this route is used to get the location details - pre-populate
// app.get('/getLocationDetails', passport.authenticate('jwt', {session: false}), function(req, res){
//     console.log("Data received in request body for getLocationDetails, kafka frontend", req.query.id)
//     const dataForKafkaBackend={
//         propert_id  : req.query.id
//     }
//     kafka.make_request('get_loc_details',dataForKafkaBackend, function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.send({
//                 status  : results.status,
//                 message : results.message
//             })
//         }else{
//             console.log("Inside else");
//                 res.send({
//                     status          : results.status,
//                     fetchedProperty : results.fetchedProperty,
//                     message         : results.message
//                 });

//                 res.end();
//             }
        
//     });
// });


// //this route is used to save the property location details eneterd by the owner
// app.post('/savelocation', passport.authenticate('jwt', {session: false}), function(req, res){
//     console.log("Data received in request body", req.body)
//     kafka.make_request('save_location',req.body, function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.json({
//                 status:"error",
//                 msg:"System Error, Try Again."
//             })
//         }else{
//             console.log("Inside else");
//                 res.json({
//                     updatedList:results
//                 });

//                 res.end();
//             }
        
//     });
// });


// //configuring storage
// const storage=multer.diskStorage({
//     destination : (req, file, cb)=>{
//         cb(null,'./uploads');
//         //let i=0;
//     },
//     filename : (req, file, cb)=>{
//         console.log("Payload owner id: ",req.user.userid)
//         console.log("Inside multer",req.body);
//         console.log("Inside multer",file);
//         const newFilename=`${req.user.userid}_${req.body.property_iden}_${req.body.i}${path.extname(file.originalname)}`;
//         req.body.i++;
//         console.log("i=",req.body.i)
//         // console.log("asf" + req.files)
//         cb(null,newFilename);
//     }
// })
// const upload=multer({storage : storage}).array('selectedFile',5);

// //storing photos using mongo
// app.post('/photos', passport.authenticate('jwt', {session: false}), upload,
// (req, res) => {
//     console.log("inside photos upload.....",req.body);
//     req.body.photoCount=parseInt(req.body.photoCount)
//     console.log("Count count ",req.body.photoCount, req.body, typeof req.body.photoCount);
//     PropertyModule.findOneAndUpdate({ "_id" : req.body.property_iden, "owner" : req.user.userid }, 
//     {
//         "$set": {
//             "noOfImages" : req.body.photoCount
//         }
//     },

//     function(err, doc) {
//         console.log(doc)
//         if(err) {
//             res.send({ 
//                 status  : 400,
//                 message : "Number of images update failed."
//             })
//         } else {
//             res.send({ 
//                 status  : 200,
//                 message : "Number of images update succeeded."
//             })
//         }
//     })
// })


// //Getting the count of photos mongo db
// app.post('/savepricing', passport.authenticate('jwt', {session: false}), function(req, res){
//     console.log("Data received in request body in savepricing", req.body)
//     kafka.make_request('save_pricing',req.body, function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.send({
//                 status  : results.status,
//                 message : results.message
//             })
//         }else{
//             console.log("Result to be sent from kafka frontend to frontend")
//             console.log("Inside else");
//                 res.send({
//                     status  : results.status,
//                     message : results.message
//                 });

//                 res.end();
//             }
        
//     });
// });


// //Getting the count of photos mongo db
// app.get('/getPhotoCount',passport.authenticate('jwt', {session: false}),
// (req, res) => {
//     console.log("inside getPhotoCount", req.user.userid,req.query.proper_id);
//     console.log(typeof req.user.userid,typeof req.query.proper_id)
//     PropertyModule.findOne({ "_id" : req.query.proper_id, "owner" : req.user.userid }, function (err, result) {
//         console.log("The result we fetched from the database is-",result)
//         console.log("arguments", arguments)
//         if(err) {
//             res.send({ 
//                 status  : 400,
//                 message : "Failed while getting the number of images"
//             })
//         } else {
//             console.log("In success........",result.noOfImages)
//             if(result.noOfImages===undefined){
//                 console.log("Entered undefined")
//                 result.noOfImages=0
//             }
//             console.log("Number of images in photoCount",result.noOfImages)
//             res.send({
//                 status : 200,
//                 prop_photo_count : result.noOfImages
//             })
//         }
//     });
// })


// //this route is used to get the pricing details - pre-populate
// app.get('/getPricingDetails', passport.authenticate('jwt', {session: false}), function(req, res){
//     console.log("Data received in getPricingDetails, kafka frontend", req.query.id)
//     const dataToKafkaBackend={
//         propertyID : req.query.id
//     }
//     kafka.make_request('getpricing_details',dataToKafkaBackend, function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.send({
//                 status  : results.status,
//                 message : results.messages
//             })
//         }else{
//             console.log("Inside else");
//                 res.send({
//                     status          : results.status,
//                     fetchedProperty : results.fetchedProperty,
//                     message         : results.messages
//                 });

//                 res.end();
//             }
        
//     });
// });


// //this route is used to save the pricing details
// app.post('/getPricingDetails', passport.authenticate('jwt', {session: false}), function(req, res){
//     console.log("Data received in request body", req.body)
//     kafka.make_request('getpricing_details',req.body, function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.json({
//                 status:"error",
//                 msg:"System Error, Try Again."
//             })
//         }else{
//             console.log("Inside else");
//                 res.json({
//                     updatedList:results
//                 });

//                 res.end();
//             }
        
//     });
// });


// //this route is used to get the details for details
// app.get('/getDetailsForDetails', passport.authenticate('jwt', {session: false}), function(req, res){
//     console.log("Data received inside getDetailsForDetails kafka frontend",req.query.id)
//     const dataForBackend={
//         prop_id : req.query.id
//     }
//     kafka.make_request('get_details_fordetails',dataForBackend, function(err,results){
//         console.log('in getDetailsForDetails result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.send({ 
//                 status  : results.status,
//                 message : results.message
//             })
//         }else{
//             console.log("Inside else",results.fetchedProperty);
//             res.send({ 
//                 status          : results.status,
//                 fetchedProperty : results.fetchedProperty,
//                 message         : results.message
//             })
//                 res.end();
//             }
//     });
// });


// //this route is created a new property row
// app.post('/createPropertyRow', passport.authenticate('jwt', {session: false}), function(req, res){
//     console.log("insdie createPropertyRow, Kafka frontend", req.query.id)
//     const dataForBackend={
//         ownerid : req.query.id
//     } 
//     kafka.make_request('create_prop_row',dataForBackend,function(err,results){
//         console.log('in result');
//         console.log("Inside createPropertuyRow, results received from kafka frontend",results);
//         if (err){
//             console.log("Inside err");
//             res.send({
//                 status           : results.status,
//                 errorMessage     : results.errorMessage
//             })
//         }else{
//             console.log("Inside else");
//             res.send({ 
//                 status      : results.status,
//                 ownerID     : results.ownerID,
//                 propertyID  : results.propertyID
//             });
//                 res.end();
//             }
        
//     });
// });


// //route to handle traveller signup with mongo
// app.post('/signup',function(req,res){
//     console.log("Inside traveller signup using MONGODB");
//     console.log("Req Body : ",req.body);
//     if(!req.body.email || !req.body.password) {
//         res.json({ 
//             status: 400, 
//             message: 'Please enter email and password.' 
//         });
//     }else {
//             console.log("inside else traveller has not left the username and password field blank")
//             UserModule.findOne({email:req.body.email} ,function(err, user) {
//                 console.log("Found user ?",user," Error?",err)
//                 if (err) {
//                     console.log("There was an error while finding the traveller",err);
//                     throw err;
//                 }
//                 if (!user) {
//                     console.log("No traveller found, so we can create a traveller account for him/her")
//                     var newUser = new UserModule({
//                         _id             : new mongoose.Types.ObjectId(),
//                         firstName       : req.body.firstName,
//                         lastName        : req.body.lastName,
//                         email           : req.body.email,
//                         password        : req.body.password,
//                         typeOfPerson    : "traveller"
//                     });
//                     newUser.save(function(err) {
//                         if (err) {
//                         console.log("Error while saving the new traveller:",err)
//                         }
//                         console.log("No error saving new traveller")
//                         res.json({ 
//                             status  : 200, 
//                             message : 'Successfully created new traveller.' 
//                         });
//                     });
//                 } else {
//                     console.log("Email address already ede marre, sumne login madu......")
//                     return res.json({ 
//                         status  : false, 
//                         message : 'Email address already exists.'
//                     });
//                 }
//             })
//     }
// });


// //route to handle traveller Login request using mongo
// app.post('/login',function(req,res,next){
//     console.log("Inside traveller Login Post Request mongo");
//     console.log("Traveller Login Req Body : ",req.body);
//     if(!req.body.email || !req.body.password) {
//         res.json({ success: false, message: 'Please enter email and password.' });
//     }else {
//             console.log("inside else traveller login, traveller hasn't left username and password field blank")
//             UserModule.findOne({email : req.body.email, typeOfPerson : "traveller"}, function(err, user){
//                 console.log("Traveller Found ?",user, "Error ?", err)
//                 if (err) {
//                     console.log("Error occurred while finding for the traveller",err);
//                     throw err;
//                 }
//                 const payload = {
//                     email   : user.email,
//                     userid  : user._id,
//                     expires : Date.now() + parseInt(process.env.JWT_EXPIRATION_MS),
//                 };

//                 console.log("Displaying payload in traveller login....",payload)

//                 if (!user) {
//                     console.log("user not found, kindly sign-up  before logging in")
//                     res.json({ 
//                         status: 400, 
//                         message: 'Kindly sign-up  before logging in.' 
//                     });
//                 } else {
//                     console.log("Email address found :-D ",req.body.password,user.password)

//                     bcrypt.compare(req.body.password,user.password,(err,result)=>{
//                         if(err){
//                             throw err;
//                         }
//                         console.log("Does the traveller password match ?",result)
//                         if(result==true){

//                           /** assigns payload to req.user */
//                           req.login(payload, {session: false}, (error,success) => {
//                             console.log("Back from login......",error,success)
//                             if (error) {
//                             res.status(400).send({ error });
//                             }
//                           })
                        

//                           // Create token if the password matched and no error was thrown
//                           var token = jwt.sign({payload}, config.secret, {
//                             expiresIn: 10080 // in seconds
//                           });

//                           //Here we are setting up the JWT token in cookie, so that user can be authorized for the future requests.
//                           res.cookie("jwt", token, {
//                             expires: new Date(Date.now() + 900000),
//                             httpOnly: true
//                           });

//                           console.log("Token",token,"UserID",user._id );

//                           res.json({ 
//                               status   : 200, 
//                               token    : 'JWT ' + token,
//                               userid   : user._id 
//                             });
//                         }else{
//                             res.send({ 
//                                 status: 400, 
//                                 message: 'Authentication failed. Passwords did not match.' 
//                             });
//                         }
//                     })
//                 }
//             })
//     }
// })


// //this route is used to get the where drop-down details for traveller dashboard
// app.get('/getWhereDropdownDetails', function(req, res){
//     console.log("Inside getWhereDropdownDetails kafkaFrontend");
//     kafka.make_request('getwhere_drop_details', '' , function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.send({
//                 status  : results.status,
//                 message : results.message
//             })
//         }else{
//                 console.log("Details fetched for dropdown are:",results);
//                 res.send({
//                     status   : results.status,
//                     property : results.property,
//                     message  : results.message
//                 })
//             }
//     });
// });


// //this route is used to get the booked properties for traveller
// app.get('/getBookedProperties', function(req, res){
//     console.log("Inside received @Kafka frontend....",req.query.id)
//     const dataFoKafkaBackend={
//         propID : req.query.id
//     }
//     kafka.make_request('get_booked_props',dataFoKafkaBackend, function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.send({
//                 status  : results.status,
//                 message : results.message
//             })
//         }else{
//             res.send({
//                 status     : results.status,
//                 bkgHistory : results.bkgHistory,
//                 message    : results.message
//             })
//         }
//     });
// });


// //this route will fetch available properties based on traveller selection
// app.get('/getAvailableProperties', passport.authenticate('jwt', {session: false}), function(req, res){
//     console.log("Data received in getAvailableProperties kafka frontend", req.query)
//     const qParamsForKafkaBackend={
//         params : req.query
//     }
//     kafka.make_request('get_avail_props',qParamsForKafkaBackend, function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.send({
//                 status  : results.status,
//                 message : results.message
//             })
//         }else{
//             console.log("Inside else");
//                 res.send({
//                     status            : results.status,
//                     avail_prop_detail : results.avail_prop_detail,
//                     message           : results.message
//                 });

//                 res.end();
//             }
        
//     });
// });


// //this route is used to get the details about the property
// app.post('/getDetailsAboutProperty', passport.authenticate('jwt', {session: false}), function(req, res){
//     console.log("Data received in request body", req.body)
//     kafka.make_request('get_detailsabout_props',req.body, function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.json({
//                 status:"error",
//                 msg:"System Error, Try Again."
//             })
//         }else{
//             console.log("Inside else");
//                 res.json({
//                     updatedList:results
//                 });

//                 res.end();
//             }
        
//     });
// });


// //this route is used to post the details about booking
// app.post('/postDetailsAboutBooking', passport.authenticate('jwt', {session: false}), function(req, res){
//     console.log("Data received in request body", req.body)
//     kafka.make_request('post_details_about_booking',req.body, function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.json({
//                 status:"error",
//                 msg:"System Error, Try Again."
//             })
//         }else{
//             console.log("Inside else");
//                 res.json({
//                     updatedList:results
//                 });

//                 res.end();
//             }
        
//     });
// });



// app.post('/book', function(req, res){
//     console.log("Data received in request body", req.body)
//     kafka.make_request('post_book',req.body, function(err,results){
//         console.log('in result');
//         console.log(results);
//         if (err){
//             console.log("Inside err");
//             res.json({
//                 status:"error",
//                 msg:"System Error, Try Again."
//             })
//         }else{
//             console.log("Inside else");
//                 res.json({
//                     updatedList:results
//                 });

//                 res.end();
//             }
        
//     });
// });


app.get("/name",function(req,res){
    kafka.make_request('sampleTopic',req.body, function(err,results){
        console.log('in result');
        console.log(results);
        if (err){
            console.log("Inside err");
            res.send({
                status:"error",
                msg:"System Error, Try Again."
            })
        }else{
            console.log("Inside else");
                res.send({
                    msg:"Success"
                });

                res.end();
            }
        
    });
})


//start your server on port 8081
app.set('port', process.env.PORT || 8081);
app.listen(app.get("port"));
console.log("Server Listening on port 8081");