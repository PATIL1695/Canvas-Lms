const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const passportJWT = require('passport-jwt');
const JWTStrategy = passportJWT.Strategy;
const bcrypt = require('bcryptjs');
var config = require('./main');

//const { secret } = require('./keys');

//const UserModel = require('./models/user');
var UserModel = require('./models/user');


module.exports = function(passport) {
  console.log("inside passport function.........")
    passport.use(
      new LocalStrategy(
        {
          usernameField: "email",
          passwordField: "password"
        },
        function(email, password, done) {
          console.log("Inner function: I am called")
          UserModel.findOne({ email: email }, (err, user) => {
            console.log(console.log("User Found ??????????",user,"Error???????????",err))
            if (err) {
              return done(err);
            }
            if (!user) {
              return done(null, false);
            }
            bcrypt.compare(password, user.password, (err, passwordsMatch) => {
              if (err) throw err;
  
              if (passwordsMatch){
                console.log("Inside passport password match aythu");
                return done(null, user)
              } 
              else return done("Incorrect username/password");
            });
          });
        }
      )
    );
  
    passport.use(
      new JWTStrategy(
        {
          jwtFromRequest: req => req.cookies.jwt,
          secretOrKey: config.secret
        },
        (jwtPayload, done) => {
          console.log("Inside passport jwt")
          if (jwtPayload.expires > Date.now()) {
            console.log("jwt expired")
            return done("jwt expired");
          } 
          console.log("jwt not expired")
          return done(null, jwtPayload);
        }
      )
    );
  };

