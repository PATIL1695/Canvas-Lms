const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const passportJWT = require('passport-jwt');
const JWTStrategy = passportJWT.Strategy;
var UserModule = require('../models/user');
var PropertyModule = require('../models/property');
var BookingModule = require('../models/booking');
var config = require('../config/main');
var cookieParser = require('cookie-parser');
var mongoose = require('mongoose');
var express = require('express');
var app = express();
const bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');

//Bringing in passport strategy that we just defined
require('../config/passport')(passport);

// need cookieParser middleware before we can do anything with cookies
app.use(cookieParser(config.secret))

mongoose.connect(config.database,()=>{
    console.log("Connected to mongoose")
});


function handle_request(msg, callback){
   
    console.log("Inside traveller Login Post Request mongo");
    console.log("Req Body : ",msg);
    if(!msg.email || !msg.password) {
        //res.json({ success: false, message: 'Please enter email and password.' });
        callback(null, { tokenStat:false, success: false, message: 'Please enter email and password.' })
    }else {
        console.log("inside else traveller login", msg.email,typeof msg.email)
        UserModule.findOne({email : msg.email}, function(err, user){
            console.log("inisde find....",user)
            if (err) {
                console.log("Error",err);
                throw err;
            }

            if (!user) {
                console.log("user not found, kindly sign-up  before logging in")
                //res.json({ success: false, message: 'Kindly sign-up  before logging in.' });
                callback(null, { tokenStat:false, success: false, message: 'Kindly sign-up  before logging in.' })
            } else {
                //setting up the load
                const payload = {
                    username: user.email,
                    userid: user._id
                };

                console.log("Email address found :-D ",msg.password,user.password)

                bcrypt.compare(msg.password,user.password,(err,result)=>{
                    if(err){
                        throw err;
                    }
                    console.log("Does the traveller password match ?",result)
                    if(result==true){

                        // Create token if the password matched and no error was thrown
                        var token = jwt.sign({payload}, config.secret, {
                        expiresIn: 10080 // in seconds
                        });

                        //Here we are setting up the JWT token in cookie, so that user can be authorized for the future requests.
                        // res.cookie("jwt", token, {
                        // expires: new Date(Date.now() + 900000),
                        // httpOnly: true
                        // });

                        //res.json({ success: true, token: 'JWT ' + token });
                        callback(null, { tokenStat:true, success: true, token:  token })

                    }else{
                        //res.send({ success: false, message: 'Authentication failed. Passwords did not match.' });
                        callback(null, { tokenStat:false, success: false, message: 'Authentication failed. Passwords did not match.' })
                    }
                })
            }
        })
    }
};

exports.handle_request = handle_request;











