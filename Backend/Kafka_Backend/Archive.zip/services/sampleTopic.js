
function handle_request(msg, callback){
    console.log("Hitting sample topic")
    callback(null, {
        status            : 200,
        message           : "Kafka backend"
    })
}




exports.handle_request = handle_request;