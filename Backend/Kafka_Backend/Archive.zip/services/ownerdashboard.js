const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const passportJWT = require('passport-jwt');
const JWTStrategy = passportJWT.Strategy;
var UserModule = require('../models/user');
var PropertyModule = require('../models/property');
var BookingModule = require('../models/booking');
var config = require('../config/main');
var cookieParser = require('cookie-parser');
var mongoose = require('mongoose');
var express = require('express');
var app = express();
const bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
var async = require("async");

//Bringing in passport strategy that we just defined
require('../config/passport')(passport);

// need cookieParser middleware before we can do anything with cookies
app.use(cookieParser(config.secret))

mongoose.connect(config.database,()=>{
    console.log("Connected to mongoose")
});


function handle_request(msg, callback){
    console.log("Fetch details for owner dashboard- server side- mongo",msg,"..........",msg.userid);
    PropertyModule.find({owner : msg.userid}, function (err, result) {
        if(err){
            // res.send({
            //     status  : 400,
            //     message : "Failed while fetching data for owner dashboard details"
            // })
            callback(null, {
                status  : 400,
                message : "Failed while fetching data for owner dashboard details"
            })
        }else{
            let info;
            console.log("Inside /getDetailsForDashboard success.....",result)
            async.forEachOf(result, (ele, key, cb) => {
                console.log("Displaying ele",ele)
                if((ele.country !="" && ele.country!=null) &&
                (ele.headline !="" && ele.headline!=null)){ 
                    console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Complete~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                    info="Complete";
                }else{
                    info="In-complete";
                }
                PropertyModule.findOneAndUpdate({ "_id" : ele._id}, 
                {
                    "$set": {
                        "status" : info
                    }
                },(err,res)=>{
                    if(err){
                        console.log("Failed inside for loop while accessing database",err)
                        return cb(err);
                    }else{
                        console.log("Successfully able to access database inside for loop")
                        cb();  
                    }
                })

            },(err)=>{
                if (err) console.error("Erro inside async module",err.message);
                PropertyModule.find({owner : msg.userid}, function (err, resu) {
                    if(err){
                        callback(null, {
                            status  : 400,
                            message : err
                        })
                    }else{
                        console.log("After setting the status",resu);
                        callback(null, {
                            status   : 200,
                            property : resu,
                            message  : "Successfully fetched the details for owner dashboard"
                        })
                    }
                })
            })
        }
    })
}

exports.handle_request = handle_request;