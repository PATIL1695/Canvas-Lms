const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const passportJWT = require('passport-jwt');
const JWTStrategy = passportJWT.Strategy;
var UserModule = require('../models/user');
var PropertyModule = require('../models/property');
var BookingModule = require('../models/booking');
var config = require('../config/main');
var cookieParser = require('cookie-parser');
var mongoose = require('mongoose');
var express = require('express');
var app = express();
const bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');

//Bringing in passport strategy that we just defined
require('../config/passport')(passport);

// need cookieParser middleware before we can do anything with cookies
app.use(cookieParser(config.secret))

mongoose.connect(config.database,()=>{
    console.log("Connected to mongoose")
});


function handle_request(msg, callback){
    let qParams=msg.params;
    console.log("The data received at the backend is",qParams);
    console.log(qParams.location);
    console.log("yyooma dates: ", (new Date(qParams.startDate).toISOString().split('T')[0]));
    PropertyModule.find({
        startDate : { $lt : (new Date(qParams.startDate).toISOString().split('T')[0])},
        endDate   : { $gt : (new Date(qParams.startDate).toISOString().split('T')[0])},
        city      : qParams.location
    }, 
        function (err, result) {
        if(err){
            callback(null, {
                status  : 400,
                message : "Failed while fetching available properties based on user selection."
            })
        }else{
            console.log("Available properties for these criteria are.....",result)
            callback(null, {
                status            : 200,
                avail_prop_detail : result,
                message           : "These are the available properties for ths traveller :-)"
            })
        }
    });
}


exports.handle_request = handle_request;