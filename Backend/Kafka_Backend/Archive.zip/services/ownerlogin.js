const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const passportJWT = require('passport-jwt');
const JWTStrategy = passportJWT.Strategy;
var UserModule = require('../models/user');
var PropertyModule = require('../models/property');
var BookingModule = require('../models/booking');
var config = require('../config/main');
var cookieParser = require('cookie-parser');
var mongoose = require('mongoose');
var express = require('express');
var app = express();
const bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');

//Bringing in passport strategy that we just defined
require('../config/passport')(passport);

// need cookieParser middleware before we can do anything with cookies
app.use(cookieParser(config.secret))

mongoose.connect(config.database,()=>{
    console.log("Connected to mongoose")
});


function handle_request(msg, callback){
    console.log("Inside owner Login Post Request mongo");
    if(!msg.email || !msg.password) {
        callback(null, { success: false, message: 'Please enter email and password.' })
    }else {
            console.log("inside else of owner signup/login, email & passwords are not blank")
            UserModule.findOne({email : msg.email}, (err, user)=>{
                if (err) {
                    console.log("Error occurred while check if a owner is present with this owner id",err);
                    throw err;
                }
                if (!user) {
                    console.log("owner with this email not found,so let's create an account for him")
                    
                    const { email, password } = msg;
                    const hashCost = 10;

                    try {
                        const userDocument = new UserModule({
                            _id         : new mongoose.Types.ObjectId(), 
                            email       : email, 
                            password    : password 
                        });
                        userDocument.save().then(function(){
                            console.log(arguments);
                        }).catch(function(){
                            console.log("Error while saving new owner ", arguments)
                        });
                        
                        callback(null, { 
                            status   : 201,
                            message2 : "Sir/Mam new account has been created for you, kindly login :-)" 
                        })
                        
                    } catch (error) {
                        res.status(400).send({
                        error: 'req body should take the form { email, password }',
                        });

                        callback(null, {
                            error: 'req body should take the form { email, password }',
                        })
                    }
                } else {
                    console.log("User with this email found, let him llogin")
                    passport.authenticate(
                        'local',
                        { session: false },
                        (error, user) => {
                          console.log("Inside passport authenticate",user,error);
                          if (error || !user) {
                            callback(null, {
                                status : 400,
                                err    : "Passport authentication error"
                            })
                          }
                    
                          /** This is what ends up in our JWT */
                          const payload = {
                            email   : user.email,
                            userid  : user._id,
                            expires : Date.now() + parseInt(process.env.JWT_EXPIRATION_MS),
                          };
                    
                          /** assigns payload to req.user */
                          req.login(payload, {session: false}, (error,success) => {
                            console.log("Back from login......",error,success)
                            if (error) {
                              //res.status(400).send({ error });
                              callback(null, {
                                status : 400,
                                error
                              })
                            }
                    
                            /** generate a signed json web token and return it in the response */
                            const token = jwt.sign(JSON.stringify(payload), config.secret);
                            
                            /** assign our jwt to the cookie */
                            //res.cookie('jwt', token, { httpOnly: true});
                            console.log("Displaying jwt token",token);
                            res.send({ 
                                status    : 200,
                                message2  : "Welcome back!!!", 
                                token     : token  
                            });
                            callback(null, { 
                                status    : 200,
                                message2  : "Welcome back!!!", 
                                token     : token  
                            })
                            
                          });
                        },
                    )(req, res,next);
                }
            })
    }
}

exports.handle_request = handle_request;
