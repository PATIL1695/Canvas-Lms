const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const passportJWT = require('passport-jwt');
const JWTStrategy = passportJWT.Strategy;
var UserModule = require('../models/user');
var PropertyModule = require('../models/property');
var BookingModule = require('../models/booking');
var config = require('../config/main');
var cookieParser = require('cookie-parser');
var mongoose = require('mongoose');
var express = require('express');
var app = express();
const bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');

//Bringing in passport strategy that we just defined
require('../config/passport')(passport);

// need cookieParser middleware before we can do anything with cookies
app.use(cookieParser(config.secret))

mongoose.connect(config.database,()=>{
    console.log("Connected to mongoose")
});


function handle_request(msg, callback){
    console.log("Request received by the node to store the booking details, mongo");
    console.log("Traveller id is:",msg.traveller_id)
    console.log("Property id is:",msg.property_id)
    console.log("Owner id:",msg.ownerid)
    console.log("What is this ID ?",req.query.id)
    var newProperty = new BookingModule({
        _id             : new mongoose.Types.ObjectId(),
        travellerid     : msg.traveller_id,
        propertyid      : msg.property_id,
        ownerid         : msg.ownerid,
        startDate       : msg.from,
        endDate         : msg.to,
        adults          : msg.adults,
        children        : msg.children,
    });
    
    newProperty.save(function(err) {
        if (err) {
        console.log("Error while trying to make a booking, please try later",err)
        }
        console.log("Successfully made the booking")
        // res.json({ 
        //     status  : 200, 
        //     message : 'Successfully made the booking.' 
        // });
        callback(null, { 
            status  : 200, 
            message : 'Successfully made the booking.' 
        })
    });
}


exports.handle_request = handle_request;