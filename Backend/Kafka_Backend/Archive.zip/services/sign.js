const passport = require('passport');
var UserModule = require('../models/user');
var PropertyModule = require('../models/property');
var BookingModule = require('../models/booking');
var config = require('../config/main');
var cookieParser = require('cookie-parser');
var mongoose = require('mongoose');
var express = require('express');
var app = express();

//Bringing in passport strategy that we just defined
require('../config/passport')(passport);

// need cookieParser middleware before we can do anything with cookies
app.use(cookieParser(config.secret))

mongoose.connect(config.database,()=>{
    console.log("Connected to mongoose")
});


function handle_request(msg, callback){
   
    console.log("Inside sigin kafka backend", msg);
    console.log("after callback");

    if(!msg.email || !msg.password) {
        //res.json({ success: false, message: 'Please enter email and password.' });
        callback(null, {success: false, message: 'Please enter email and password.'})
    }else {
            console.log("inside else")
            UserModule.findOne({email:msg.email} ,function(err, user) {
                console.log("inisde find....")
                if (err) {
                    console.log(err);
                    throw err;
                }
                if (!user) {
                    console.log("inside no error")
                    var newUser = new UserModule({
                        //firstName       : req.body.firstName,
                        //lastName        : req.body.lastName,
                        _id             : new mongoose.Types.ObjectId(),
                        email           : msg.email,
                        password        : msg.password,
                        //typeOfPerson    : "traveller"
                    });
                    newUser.save(function(err,record) {
                        if (err) {
                        console.log("Error :",err)
                        }
                        console.log("Newly inserted record",record)
                        console.log("No error")
                        //res.json({ success: true, message: 'Successfully created new user.' });
                        callback(null, { success: true, message: 'Successfully created new user.' })
                    });
                } else {
                    console.log("Email address alread ede marre......")
                    //return res.json({ success: false, message: 'That email address already exists.'});
                    callback(null, { success: false, message: 'That email address already exists.'})
                }
            })
    }
};

exports.handle_request = handle_request;



// console.log("Inside traveller signup using MONGODB");
//     console.log("Req Body : ",req.body);
//     if(!req.body.email || !req.body.password) {
//         res.json({ success: false, message: 'Please enter email and password.' });
//     }else {
//             console.log("inside else",UserModule)
//             UserModule.findOne({email:req.body.email} ,function(err, user) {
//                 console.log("inisde find....")
//                 if (err) {
//                     console.log(err);
//                     throw err;
//                 }
//                 if (!user) {
//                     console.log("inside no error")
//                     var newUser = new UserModule({
//                         firstName       : req.body.firstName,
//                         lastName        : req.body.lastName,
//                         email           : req.body.email,
//                         password        : req.body.password,
//                         typeOfPerson    : "traveller"
//                     });
//                     newUser.save(function(err) {
//                         if (err) {
//                         console.log("Error :",err)
//                         }
//                         console.log("No error")
//                         res.json({ success: true, message: 'Successfully created new user.' });
//                     });
//                 } else {
//                     console.log("Email address alread ede marre......")
//                     return res.json({ success: false, message: 'That email address already exists.'});
//                 }
//             })
//     }


