var mongoose=require('mongoose');
var Schema = mongoose.Schema;

//property schema
var propertySchema = Schema({
    _id: Schema.Types.ObjectId,
    owner: Schema.Types.ObjectId,
    created : {
      type: Boolean
    },
    country : {
      type: String
    },
    streetAddress: {
      type: String
    },
    unitSuite: {
      type: String
    },
    city: {
      type: String
    },
    state: {
      type: String
    },
    zipCode: {
      type: Number
    },
    headline: {
      type: String
    },
    propertyDescription: {
      type: String
    },
    apartment: {
      type: String
    },
    berooms: {
      type: Number
    },
    accommodates: {
      type: Number
    },
    bathrooms: {
      type: Number
    },
    startDate: {
      type: Date
    },
    endDate: {
      type: Date
    },
    amount: {
      type: Number
    },
    minStay: {
      type: Number
    },
    status: {
      type: String
    },
    noOfImages: {
      type: Number
    },
  
    bookingList: { 
        type : { type: Schema.Types.ObjectId, ref: 'Booking' } 
    }
  });

  module.exports= mongoose.model('Property', propertySchema,'Properties');