
var mongoose=require('mongoose');
var Schema = mongoose.Schema;

//Booking schema
var bookingSchema = Schema({
    startDate: {
        type :Date
    },
    endDate: {
        type :Date
    },
    adults: {
        type :Number
    },
    children: {
        type :Number
    }   
});


module.exports= mongoose.model('Booking', bookingSchema,'Bookings');