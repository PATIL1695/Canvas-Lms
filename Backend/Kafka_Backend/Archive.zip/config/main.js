module.exports = {
    'secret': 'longobnoxiouspassphrase',
    'database': 'mongodb://nayak11:nayak11@ds117431.mlab.com:17431/homeaway'
};