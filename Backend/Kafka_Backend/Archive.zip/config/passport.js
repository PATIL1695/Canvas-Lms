const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const passportJWT = require('passport-jwt');
const JWTStrategy = passportJWT.Strategy;
const bcrypt = require('bcryptjs');
var config = require('../config/main');

//const { secret } = require('./keys');

//const UserModel = require('./models/user');
var UserModel = require('../models/user');


module.exports = function(passport) {
    passport.use(
      new LocalStrategy(
        {
          usernameField: "email",
          passwordField: "password"
        },
        function(email, password, done) {
          UserModel.findOne({ email: email }, (err, user) => {
            if (err) {
              return done(err);
            }
            if (!user) {
              return done(null, false);
            }
            bcrypt.compare(password, user.password, (err, passwordsMatch) => {
              if (err) throw err;
  
              if (passwordsMatch) return done(null, user);
              else return done("Incorrect username/password");
            });
          });
        }
      )
    );
  
    passport.use(
      new JWTStrategy(
        {
          jwtFromRequest: req => req.cookies.jwt,
          secretOrKey: config.secret
        },
        (jwtPayload, done) => {
          if (jwtPayload.expires > Date.now()) {
            return done("jwt expired");
          } 
          return done(null, jwtPayload);
        }
      )
    );
  };
