var connection =  new require('./kafka/connection');
//topics files
//var signin = require('./services/signin.js');
var Books = require('./services/books.js');
var Sign = require('./services/sign.js');
var TravLogin = require('./services/travlogin.js');
var OwnerLogin= require('./services/ownerlogin.js')
var OwnerDashboard = require('./services/ownerdashboard.js')
var BookingDetailsForOwnDash = require('./services/bkgdetailsforowndash.js')
var BookingDetailsForDetails = require('./services/bkgdetailsfordetails.js')
var SaveDetails = require('./services/savedetails.js')
var GetLocationDetails = require('./services/getLocationDetails.js')
var SaveLocationDetails = require('./services/saveLocationDetails.js')
var GetPricingDetails = require('./services/getPricingDetails.js')
var GetDetailsForDetails = require('./services/getDetailsForDetails.js')
var CreatePropRow = require('./services/createPropRow.js')
var GetWhereDropDownDetails = require('./services/getWhereDetails.js')
var GetBookedProps = require('./services/getBookedProps.js')
var GetAvailProps = require('./services/getAvailProps.js')
var GetDetailsAboutProps = require('./services/getDetailsAboutProps.js')
var PostDetailsAboutBooking = require('./services/PostDetailsAboutBooking.js')
var SaveDetailsFromDetails = require('./services/saveDetailsFromDetails.js')
var SavePricingDetails = require('./services/savePricingDetailsAboutProperty.js')
var SampleTopic = require('./services/sampleTopic.js')

function handleTopicRequest(topic_name,fname){
    console.log("Hitting kafka backedn. Topic_name",topic_name);
    var consumer = connection.getConsumer(topic_name);
    var producer = connection.getProducer();
    console.log('server is running ');
    consumer.on('message', function (message) {
        console.log('message received for ' + topic_name +" ", fname);
        console.log(JSON.stringify(message.value));
        var data = JSON.parse(message.value);
        
        fname.handle_request(data.data, function(err,res){
            console.log('after handle'+res);
            var payloads = [
                { topic: data.replyTo,
                    messages:JSON.stringify({
                        correlationId:data.correlationId,
                        data : res
                    }),
                    partition : 0
                }
            ];
            producer.send(payloads, function(err, data){
                console.log(err)
                console.log(data);
            });
            return;
        });
        
    });
}
// Add your TOPICs here
//first argument is topic name
//second argument is a function that will handle this topic request
// handleTopicRequest("post_book",Books)
// handleTopicRequest("trav_sign",Sign)
// handleTopicRequest("trav_login",TravLogin)
// handleTopicRequest("own_login",OwnerLogin)
// handleTopicRequest("own_dashboard",OwnerDashboard)
// handleTopicRequest("book_details_own_dash",BookingDetailsForOwnDash)
// handleTopicRequest("get_bkg_details_for_prop",BookingDetailsForDetails)
// handleTopicRequest("get_loc_details",GetLocationDetails)
// handleTopicRequest("save_location",SaveLocationDetails)
// handleTopicRequest("getpricing_details",GetPricingDetails)
// handleTopicRequest("get_details_fordetails",GetDetailsForDetails)
// handleTopicRequest("create_prop_row",CreatePropRow)
// handleTopicRequest("getwhere_drop_details",GetWhereDropDownDetails)
// handleTopicRequest("get_booked_props",GetBookedProps)
// handleTopicRequest("get_avail_props",GetAvailProps)
// handleTopicRequest("get_detailsabout_props",GetDetailsAboutProps)
// handleTopicRequest("post_details_about_booking",PostDetailsAboutBooking)
// handleTopicRequest("save_details",SaveDetailsFromDetails)
// handleTopicRequest("save_pricing",SavePricingDetails)
handleTopicRequest("sampleTopic",SampleTopic)






















